function writeTocsv( fileName, input )
%WRITETOCSV Given a filename and an input of cell arrays, it writes the
% array into a csv
n = size(input,1);

fid = fopen(fileName, 'w+');
for i = 1 : n
    fprintf(fid, '%s,\n', input{i,:});
end
fclose(fid);

end

