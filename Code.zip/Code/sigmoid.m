function output = sigmoid( input )
%SIGMOID 
    output = 1 ./ (1 + exp(-input));

end

