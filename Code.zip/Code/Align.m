function [output frequencyChart] = Align( input )
%ALIGN Given an input of AAs, this returns both the max-aligned, and the
% frequency chart (i.e. how many AAs in each column)
%   Detailed explanation goes here
n = size(input,1);

maxNumberOfAAs = 0;
highestIndex = 0;
for i = 1 : n
    temp = size(input{i},2);
    if (maxNumberOfAAs < temp)
        maxNumberOfAAs = temp;
        highestIndex = i;
    end
end

AAfreqs = zeros(25, maxNumberOfAAs);

for i = 1 : n
    % remove leading Xs
    length = size(input{i},2);
    for j = 1 : length
        if (input{i}(j) ~= 'X')
            break;
        end
    end
    input{i} = input{i}(j:length);
    [A, B, C] = swalign(input{maxNumberOfAAs}, input{i});
    length = size(input{i},2);
    for j = 1 : length
        row = aa2int(input{i}(j));
        col = C(1) - C(2) + j;
        AAfreqs(row,col) = AAfreqs(row,col) + 1;
    end
end


% front
for i = 1 : n
    temp = '';
    [A, B, C] = swalign(input{maxNumberOfAAs}, input{i});
    for j = 1 : C(1) - C(2)
        [val idx] = max(AAfreqs(:,j));
        char = int2aa(idx);
        temp = strcat(temp, char);
    end
    input{i} = strcat(temp, input{i});
end

% end
for i = 1 : n
    temp = '';
    for j = 1 : maxNumberOfAAs - size(input{i},2)
        [val idx] = max(AAfreqs(:,maxNumberOfAAs - j - 1));
        char = int2aa(idx);
        temp = strcat(char,temp);
    end
    input{i} = strcat(input{i}, temp);
end

frequencyChart = AAfreqs;
output = input;
end

