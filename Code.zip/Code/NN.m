function [ cost Theta1 Theta2 ] = NN( inputMatrix, outputVector, numberOfHiddenLayerUnits, iterations, lambda)
%NN Runs the NN with the input matrix, corresponding output vector, number
%of nodes in the hidden layer, number of maximum iterations, and the
%regulariztion term lambda.
inputFeatures = size(inputMatrix, 2);

[w1 w2] = OneLayerNNInit(inputMatrix, outputVector, numberOfHiddenLayerUnits);

initialNNparams = [w1(:) ; w2(:)];

options = optimset('MaxIter', iterations);

CF = @(p) costFunction(p, ...
                       inputFeatures, ...
                       numberOfHiddenLayerUnits, lambda, ...
                       inputMatrix, outputVector);
[nn_params, cost] = fmincg(CF, initialNNparams, options);

Theta1 = reshape(nn_params(1:(inputFeatures + 1)*numberOfHiddenLayerUnits), (inputFeatures + 1), numberOfHiddenLayerUnits);
Theta2 = reshape(nn_params((1 + inputFeatures)*numberOfHiddenLayerUnits + 1:end),numberOfHiddenLayerUnits + 1,1);


end

