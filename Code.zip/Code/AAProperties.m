function output = AAProperties( AAPT, AART, VL, CD4, PTfreq, RTfreq )
%CREATEINPUT Outputs the Input in a matrix. Each row is a different
%patient, and the columns contain the different features.
n = min(size(AAPT,1), size(AART,1));
%20 Amino Acid count for PT and RT each, 5 composition values each 1 isoelectric
%value each, 1 VL, 1 CD4
numberOfCols = 40 + 10 + 2 + 1 + 1;
output = zeros(n, numberOfCols);
for i = 1 : n
    PT = RemoveAmbigAAs(AAPT{i}, PTfreq);
    RT = RemoveAmbigAAs(AART{i}, RTfreq);
    PTCount = aacount(PT);
    RTCount = aacount(RT);
    atomicCompPT = atomiccomp(PT);
    atomicCompRT = atomiccomp(RT);
    isoElecPT = isoelectric(PT);
    isoElecRT = isoelectric(RT);
    output(i, 1) = PTCount.A;
    output(i, 2) = PTCount.R;
    output(i, 3) = PTCount.N;
    output(i, 4) = PTCount.D;
    output(i, 5) = PTCount.C;
    output(i, 6) = PTCount.Q;
    output(i, 7) = PTCount.E;
    output(i, 8) = PTCount.G;
    output(i, 9) = PTCount.H;
    output(i, 10) = PTCount.I;
    output(i, 11) = PTCount.L;
    output(i, 12) = PTCount.K;
    output(i, 13) = PTCount.M;
    output(i, 14) = PTCount.F;
    output(i, 15) = PTCount.P;
    output(i, 16) = PTCount.S;
    output(i, 17) = PTCount.T;
    output(i, 18) = PTCount.W;
    output(i, 19) = PTCount.Y;
    output(i, 20) = PTCount.V;
    output(i, 21) = RTCount.A;
    output(i, 22) = RTCount.R;
    output(i, 23) = RTCount.N;
    output(i, 24) = RTCount.D;
    output(i, 25) = RTCount.C;
    output(i, 26) = RTCount.Q;
    output(i, 27) = RTCount.E;
    output(i, 28) = RTCount.G;
    output(i, 29) = RTCount.H;
    output(i, 30) = RTCount.I;
    output(i, 31) = RTCount.L;
    output(i, 32) = RTCount.K;
    output(i, 33) = RTCount.M;
    output(i, 34) = RTCount.F;
    output(i, 35) = RTCount.P;
    output(i, 36) = RTCount.S;
    output(i, 37) = RTCount.T;
    output(i, 38) = RTCount.W;
    output(i, 39) = RTCount.Y;
    output(i, 40) = RTCount.V;
    output(i, 41) = atomicCompPT.C;
    output(i, 42) = atomicCompPT.H;
    output(i, 43) = atomicCompPT.N;
    output(i, 44) = atomicCompPT.O;
    output(i, 45) = atomicCompPT.S;
    output(i, 46) = atomicCompRT.C;
    output(i, 47) = atomicCompRT.H;
    output(i, 48) = atomicCompRT.N;
    output(i, 49) = atomicCompRT.O;
    output(i, 50) = atomicCompRT.C;
    output(i, 51) = isoElecPT;
    output(i, 52) = isoElecRT;
    output(i, 53) = VL(i);
    output(i, 54) = CD4(i);
end

end

