function output = readCSVFile( fileName , delimiter)
%READCSVFILES Given a filename, this returns a cellarray of values
%   Detailed explanation goes here
fid = fopen(fileName);
output = fscanf(fid, '%s');
output = regexp(output, delimiter, 'split');
output = output';
fclose(fid);

if (size(output{end}, 1) < 1)
    output = output(1:end-1);
end

end

