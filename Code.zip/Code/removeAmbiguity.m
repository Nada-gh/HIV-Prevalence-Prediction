n = size(AAPT,1);

for i = 1 : n
    AAPT{i} = RemoveAmbigAAs(AAPT{i}, PTfreq);
end

n = size(AART,1);

for i = 1 : n
    AART{i} = RemoveAmbigAAs(AART{i}, RTfreq);
end