function intValue = AA2NumberMapping(aa)
% AA2NUMBER maps each 20 amino acid to a specific value
%
% Parameter:
%       - an amino acid character i.e. 'A'
% Returns:
%       - number the amino acid corresponds to i.e. AA2Number('F') = 1

% The amino acids are randomly assigned a positon from 1 to 20.
keySet = {'F', 'L', 'I', 'M', 'V', 'S', 'P', ...
            'T', 'A', 'Y', 'H', 'Q', 'N', 'K', ...
            'D', 'E', 'C', 'W', 'R', 'G'};
        
% returns the position of the given acid in the above vector
intValue = find(strcmpi(keySet, aa));
end

