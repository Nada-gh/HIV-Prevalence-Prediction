function output = RemoveAmbigAAs( input, freqChart )
%REMOVEAMBIGAAS Summary of this function goes here
%   Detailed explanation goes here
lengthOfStr = size(input,2);
output = input;
for i = 1 : lengthOfStr
    aaint = aa2int(input(i));
    % if the letter is B, it is either Asparagine or Aspartate (N or D)
    if (aaint == 21)
        r = rand;
        if (r < 0.5)
            output(i) = int2aa(3);
        else
            output(i) = int2aa(4);
        end
    % if the letter is Z, it is either Glutamine or Glutamate
    elseif (aaint == 22)
        r = rand;
        if (r < 0.5)
            output(i) = int2aa(6);
        else
            output(i) = int2aa(7);
        end
    elseif(aa2int(input(i)) > 20)
        [val AAidx] = max(freqChart(:, i));
        output(i) = int2aa(AAidx);
    end
end

end

