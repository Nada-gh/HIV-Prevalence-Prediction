function output = getSubsetAA( input, start, stop )
%GETSUBSETAA The output string is the subset of the input string
start = max(1, start);
n = size(input, 1);
output = input;
for i = 1 : n
    stopidx = min(size(input{i}, 2), stop);
    output{i} = input{i}(start:stopidx);
end

end

