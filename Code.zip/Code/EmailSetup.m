% Define these variables appropriately:
mail_address = 'aamirtothejawaid@gmail.com';            % My E-Mail Address
user_name = 'aamirtothejawaid';                          % My Username
password = 'superhp123';      % My E-Mail Password
smtp_server = 'smtp.gmail.com';               % My SMTP Server
 
% Then this code will set up the preferences properly:
setpref('Internet', 'E_mail', mail_address);
setpref('Internet', 'SMTP_Username', user_name);
setpref('Internet', 'SMTP_Password', password);
setpref('Internet', 'SMTP_Server', smtp_server);
props = java.lang.System.getProperties;
props.setProperty('mail.smtp.auth', 'true');
props.setProperty('mail.smtp.socketFactory.class', 'javax.net.ssl.SSLSocketFactory');
props.setProperty('mail.smtp.socketFactory.port', '465');