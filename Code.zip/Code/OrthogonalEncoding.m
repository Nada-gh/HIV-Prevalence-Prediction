function output = OrthogonalEncoding( PT, RT, VL, CD4 )
    n = min(size(PT,1), size(RT,1));
    numberOfCols = size(PT{1},2) * 20 + size(RT{1},2) * 20 + 1 + 1;
    output = zeros(n, numberOfCols);
    for i = 1 : n
        PTvec = EncodeAA(PT{i})';
        RTvec = EncodeAA(RT{i})';
        inputVec = [PTvec; RTvec; VL(i); CD4(i)];
        output(i, :) = inputVec';
    end
end

function sequence = EncodeAA( aa_sequence )
% EncodeAA converts a sequence of amino acids to a sequence of
% binary vectors
%
% Parameter: 
%       - aa_sequence: vector of amino acid sequence i.e. A,G,T,R...
% Returns:
%       - orthogonal binary representation of the aa sequence

    length = size(aa_sequence);
    sequence = zeros(1, length(2) * 20);

    for i = 1:length(2)
        % for each amino acid, set the correct bit to 1
        sequence((i - 1) * 20 + AA2NumberMapping(aa_sequence(i))) = 1;
    end
end

