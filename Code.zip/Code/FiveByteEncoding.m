function output = FiveByteEncoding( PT, RT, VL, CD4 )
% FiveByteEncoding encodes the PT and RT sequence using five byte encoding
% i.e. A = 00001 (not actual result, just example)...

    n = min(size(PT,1), size(RT,1));
    numberOfCols = size(PT{1},2) * 5 + size(RT{1},2) * 5 + 1 + 1;
    output = zeros(n, numberOfCols);
    
    for i = 1 : n
        PTvec = ToBinaryVector(PT{i})';
        RTvec = ToBinaryVector(RT{i})';
        inputVec = [PTvec; RTvec; VL(i); CD4(i)];
        output(i, :) = inputVec';
    end
end

function sequence = ToBinaryVector( aa_sequence )
% ConvertToFiveByte converts a sequence of amino acids to a sequence of
% binary representation
%
% Parameter: 
%       - aa_sequence: vector of amino acid sequence i.e. A,G,T,R...
% Returns:
%       - binary vector representation of the aa sequence

    length = size(aa_sequence);
    sequence = zeros(1, length(2) * 5);

    for i = 1:length(2)
        % get the decimal value of each character.
        integer_value = AA2NumberMapping(aa_sequence(i));
        % set the appropriate values in the return matrix...
        offset = ((i - 1) * 5) + 1;
        sequence(offset : offset + 4) = de2bi(integer_value, 5);
    end
end

