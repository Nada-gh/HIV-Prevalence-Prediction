function [ w1 w2 ] = OneLayerNNInit( input, output, hidden_units )
%ONELAYERNNINIT Summary of this function goes here
%   Detailed explanation goes here
n_inputs = size(input, 2);
n_output = size(output, 2);


w1 = transpose(RandInitializeWeights(n_inputs, hidden_units));
w2 = transpose(RandInitializeWeights(hidden_units, n_output));

end

