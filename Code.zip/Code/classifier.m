% !!!!!WARNING!!!!!!
%clears all current variables! disable if you don't want this!!
%clear

tic();

%TrainingPercentage = 0.85;
 
%ReadAllInput
%AART = getSubsetAA(AART, 1, 230);
 
%replace createInput with your own function. Input should be a matrix of
%inputs where each row corresponds to a particular sample.
%TotalInput = createInput(AAPT, AART, VL, CD4);
%TotalInput = OrthogonalEncoding(AAPT, AART, VL, CD4);
 
 
%[n inputFeatures] = size(TotalInput);
%TotalTarget = target(1:n);

RandomOrder = load('RandomOrder.csv'); %randperm(n);

% n_TrainingInputs is the number of inputs needed for training
% the rest is Testing code.
n_TrainingInputs = round(TrainingPercentage * n);
TrainingInput = zeros(n_TrainingInputs, inputFeatures);
TrainingOutput = zeros(n_TrainingInputs,1);
TestInput = zeros(n - n_TrainingInputs, inputFeatures);
TestOutput = zeros(n - n_TrainingInputs, 1);
 
for i = 1 : n_TrainingInputs
    TrainingInput(i,:) = TotalInput(RandomOrder(i),:);
    TrainingOutput(i,:) = TotalTarget(RandomOrder(i),:);
end
 
for i = n_TrainingInputs + 1 : n
    TestInput(i - n_TrainingInputs,:) = TotalInput(RandomOrder(i),:);
    TestOutput(i - n_TrainingInputs,:) = TotalTarget(RandomOrder(i),:);
end

% Oversample the training data
[TrainingOutputOverSampled TrainingInputOversampled] = OverSample(TrainingInput,TrainingOutput);

% Undersaple test data
[TestOutput TestInput] = UnderSample(TestInput, TestOutput);

nTestData = size(TestInput,1);
%hidden_units = 1200;
%lambda = 8;
 
% Run the neural network completely
[cost w1 w2] = NN(TrainingInputOversampled, TrainingOutputOverSampled, hidden_units, 12000, lambda);
 
 
%add the bias
Test = [ones(nTestData,1) TestInput];
TrainTest = [ones(n_TrainingInputs,1) TrainingInput];

%get hypothesis for test data
z2 = Test*w1;
a2 = sigmoid(z2);
%add the bias to the second later
a2 = [ones(nTestData,1) a2];
z3 = a2*w2;
%hypothesis is as an output of hte sigmoid function
%so it's beween 0 and 1
h = sigmoid(z3);


%Now do the same for Training Data
z2 = TrainTest*w1;
a2 = sigmoid(z2);
%add the bias to the second later
a2 = [ones(n_TrainingInputs,1) a2];
z3 = a2*w2;
%hypothesis is as an output of hte sigmoid function
%so it's beween 0 and 1
hTrain = sigmoid(z3);


Thresholds = [0.1 : 0.1 : 1]';
Results = zeros(10, 12);
for threshold = 1 : size(Thresholds,1)
    Output = h > Thresholds(threshold); %everything greater than 0.5 is considered 1

    %look for accuracy
    TestAccuracy = sum( Output == TestOutput )  / nTestData;
    TestAccuracyOnes = sum(( Output == TestOutput ) & TestOutput)  / sum(TestOutput);

    OutputTrain = hTrain > Thresholds(threshold); %everything greater than 0.5 is considered 1

    %look for training accuracy
    TrainingAccuracy = sum( OutputTrain == TrainingOutput ) / (n_TrainingInputs);
    TrainingAccuracyOnes = sum(( OutputTrain == TrainingOutput ) & TrainingOutput) / sum(TrainingOutput);
    
    %Analysis begins here
    Results(threshold, 1) = Thresholds(threshold);
    Results(threshold, 2) = lambda;
    Results(threshold, 3) = hidden_units;
    Results(threshold, 4) = TrainingPercentage;
    Results(threshold, 5) = TestAccuracy;
    Results(threshold, 6) = TestAccuracyOnes;
    Results(threshold, 7) = TrainingAccuracy;
    Results(threshold, 8) = TrainingAccuracyOnes;
    
    FalsePositives = sum( (Output ~= TestOutput) & ~TestOutput );
    FalseNegatives = sum( (Output ~= TestOutput) & TestOutput );
    
    Results(threshold, 9) = FalsePositives;
    Results(threshold, 10) = FalseNegatives;
end

TimeSpent = toc(); 
Results(:,11) = TimeSpent;
Results(:,12) = cost(end);

display(TestAccuracy);
display(TrainingAccuracy);
display(TimeSpent);