function nt_sequence = RemoveAmbiguousNucleotides(aa_sequnece, nt_sequence )
% Converts all characters in a nucleotide sequence to A, C, G, T 
% 
%
% Parameter: 
%       - aa_sequence: corrected amino acid sequence
%       - nt_sequence: raw nucleotide sequence
% Returns:
%       - orthogonal binary representation of the aa sequence
    tmp = size(nt_sequence);
    nt_size = tmp(2);
    tmp = size(aa_sequnece);
    aa_size = tmp(2);
    
    if (nt_size ~= aa_size*3)
        error('The amino acid and nucleotide sequence does not align..');
    end
    
    aa_mapping = revgeneticcode();
    
    for i = 1:nt_size
        value = nt2int(nt_sequence(i));
        
        % HACK HACK HACK!
        % attempt to resolve the ambiguity if the value is not 1-4
        % i.e. the letter is not A, C, G, T
        if (value > 4)
            % get the corresponding aa character
            offset = floor((i - 1)/3) + 1;
            aa = aa_sequnece(offset);
            % convert the amino acid into all possible nucleotides.
            map = aa_mapping.(aa);
            
            % this is the current three letter sequence.
            nt = nt_sequence(offset: offset + 2);
            
            current_match = char(map(1));
            score = swalign(current_match, nt);
            
            % find the closest match
            for z = 1:size(map)
                % check similarities between string. higher the better
                curr_score = swalign(nt, char(map(z)));
                
                if (curr_score < score) 
                    score = curr_score;
                    current_match = char(map(z));
                end
            end
            % replace the sequence with the best matching string.
            nt_sequence(offset: offset + 2) = current_match;
        elseif (strcmpi(nt_sequence(i), 'U'))
            nt_sequence(i) = 'T';
        end  
    end
end

