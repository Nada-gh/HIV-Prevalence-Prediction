function TOT = OrhCod(~)
%AlignedPT = readCSVFile('AlignedPT.csv', ',');
%PTAlign=readcvsfile( , )
%[AAPT, AART, VL, CD4]=ReadAllInput();
% i am trying to use only one row fot the two aligned sequences
AlignedPT=('PQITLWQRPLVPIRIGGQLKEALLDTGADDTVLEDMELPGRWKPKMIGGIGGFIKVXQYDQXPIEIYGHKAVGTVLIGPTPVNIIGRNLLTQLGCTLNF');
TOT =orthogonal(AlignedPT);
%out2=orthogonal(AlignedRT(1));

end 


function TOT = orthogonal(AlignedPT)% Win size=7
temp=zeros(20,1);
CAAs=zeros(7,20);
TOT=zeros(7*length(AlignedPT));
St=0; END=7;
 while (END~=length(AlignedPT))
 for i=St:END-1
Let=AlignedPT(i);
if  Let== 'A'
temp(1) = 1;
elseif Let == 'C'
temp(2) = 1;
elseif Let == 'D'
temp(3) = 1;
elseif Let == 'E'
temp(4) = 1;
elseif Let == 'F'
temp(5) = 1;
elseif Let == 'G'
temp(6) = 1;
elseif Let == 'H'
temp(7) = 1;
elseif Let == 'I'
temp(8) = 1;
elseif Let == 'K'
temp(9) = 1;
elseif Let == 'L'
temp(10) = 1;
elseif Let == 'M'
temp(11) = 1;
elseif Let == 'N'
temp(12) = 1;
elseif Let == 'P'
temp(13) = 1;
elseif Let == 'Q'
temp(14) = 1;
elseif Let == 'R'
temp(15) = 1;
elseif Let == 'S'
temp(16) = 1;
elseif Let == 'T'
temp(17) = 1;
elseif Let == 'V'
temp(18) = 1;
elseif Let == 'W'
temp(19) = 1;
elseif Let == 'Y'
temp(20) = 1;
end

CAAs(St,:)= transpose(temp);
 end 
for j=1:length(CAAs)
    TOT=[TOT,CAAs(j,:)];
    end
St=St+1;
END=END+1;
end
end

