delete FreqEncoding.csv
EmailSetup;
lambdas = [1 3 6 8 10]';
HDs = [ 170 340 680 ]';
TrainingPercentages = [0.8 0.85 0.9]';
emails = { 'aamirtothejawaid@gmail.com' };
currentTime = mat2str(uint16(clock))
attachments = { 'FreqEncoding.csv' };

ReadAllInput
AART = getSubsetAA(AART, 1, 230);
TotalInput = NucleotideFrequencyEncoding(AAPT, AART, VL, CD4);
[n inputFeatures] = size(TotalInput);
TotalTarget = target(1:n);

for q = 1 : size(lambdas, 1)
    for p = 1 : size(HDs, 1)
        for r = 1 : size(TrainingPercentages, 1)
            TrainingPercentage = TrainingPercentages(r);
            lambda = lambdas(q);
            hidden_units = HDs(p);
            classifier
            save -ascii FreqEncoding.csv Results '-append'
            heading = 'threshold lambda hiddenUnits TrainingPercentage TestAccuracy TestAccuracyOnes TrainingAccuracy TrainingAccuracyOnes FalsePositives FalseNegatives TimeSpent cost';
            Q = sprintf('');
            for result = 1 : size(Results, 1)
                Q = sprintf('%s\n%s',Q,mat2str(Results(result,:)));
            end
            S = sprintf('%s\n%s', heading, Q);
            %sendmail(emails, 'FreqEncoding Running...', S);
            clear ~lambdas ~HDs ~TrainingPercentages ~emails ~q ~p ~r ~TotalInput ~n ~inputFeatures ~TotalTarget ~attachments;
        end
    end
end

[MaxTrainingAccValue MaxTrainingAccIdx] = max(Results(:, 5));
[MaxTrainingOneAccValue MaxTrainingOneAccIdx] = max(Results(:, 6));

str1 = Results(MaxTrainingAccIdx, :);
str2 = Results(MaxTrainingOneAccIdx, :);

save -ascii FreqEncoding.csv str1 '-append';
save -ascii FreqEncoding.csv str2 '-append';

emails = { 'lordwizards@gmail.com'; 'jeffreyxu951@gmail.com' };
sendmail(emails, 'FreqEncoding Results!', 'Attached', attachments);