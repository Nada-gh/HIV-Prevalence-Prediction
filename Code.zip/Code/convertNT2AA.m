function AA = convertNT2AA( NT )
%CONVERTNT2AA Given a cell array of nucleotides, this returns the AAs
AA = nt2aa(NT, 'ACGTOnly', false);

end

