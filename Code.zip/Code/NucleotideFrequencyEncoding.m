function output = NucleotideFrequencyEncoding( PT_AA, RT_AA, VL, CD4 )
% Calculates the frequency of occurance of nucleotides in a sequence
% using a sliding window of 1, 2, and 3. 
%
% Parameter: 
%       - aa_sequence: vector of amino acid sequence i.e. A,G,T,R...
% Returns
%       - orthogonal binary representation of the aa sequence

    n = min(size(PT_AA,1), size(RT_AA,1));
    % frequency is 4 for window of 1, 16 for window of 2, and 64 for 3
    % and there are two sequences
    numberOfCols = 84*2 + 1 + 1;
    output = zeros(n, numberOfCols);
    
    for i = 1 : n
        % remove all ambiguous necleotides
        %PT_NT{i} = RemoveAmbiguousNucleotides(PT_AA{i}, PT_NT{i});
        %RT_NT{i} = RemoveAmbiguousNucleotides(RT_AA{i}, RT_NT{i});
        
        tmp = FrequencyEncoding(aa2nt(PT_AA{i}))';
        tmp2 = FrequencyEncoding(aa2nt(RT_AA{i}))';
        inputVec = [tmp; tmp2; VL(i); CD4(i)];
        output(i, :) = inputVec';
    end
end

function frequencies = FrequencyEncoding( nt_sequence )
% TODO: write the comments that nobody will ever read...
% Calculates the frequency of occurance of nucleotides in a sequence
% using a sliding window of 1, 2, and 3. 
%
% Parameter: 
%       - aa_sequence: vector of amino acid sequence i.e. A,G,T,R...
% Returns:
%       - vector of frequency .... 

    % frequency map
    map = containers.Map('KeyType','char','ValueType','int8');
    length = size(nt_sequence);
    frequencies = [];

    % build the frequencies
    for i = 1:(length(2) - 2)
        % calculate the frequency of sliding window of 1
        win1 = nt_sequence(i);
        % calculate sliding window of 2
        win2 = nt_sequence(i : i + 1);
        % calculate sliding window of 3
        win3 = nt_sequence(i : i + 2);
        
        AddToMap(map, win1);
        AddToMap(map, win2);
        AddToMap(map, win3);
    end
    
    % cover the last win2 and last 2 win1
    win2 = nt_sequence(length(2) - 1 : length(2));
    AddToMap(map, win2);
    win1 = nt_sequence(length(2) - 1);
    AddToMap(map, win1);
    win1 = nt_sequence(length(2));
    AddToMap(map, win1);
    
    %extract frequencies. Extract the values in order
    frequencies = ExtractFrequencies(map, '', 1, frequencies);
end

function freq = ExtractFrequencies(map, value, idx, freq)
% super naive method to extract frequencies...
    if (~isempty(value))
        freq = [freq GetValue(map, value)];
    end
    
    if (length(value) ~= 3) 
       freq = ExtractFrequencies(map, strcat(value, 'A'), idx, freq);
       freq = ExtractFrequencies(map, strcat(value, 'G'), idx, freq);
       freq = ExtractFrequencies(map, strcat(value, 'T'), idx, freq);
       freq = ExtractFrequencies(map, strcat(value, 'R'), idx, freq);
    end
end

function map = AddToMap(map, key)
    if (map.isKey(key))
        map(key) = map(key) + 1;
    else
        map(key) = 1;
    end
end

function value = GetValue(map, key)
    if (map.isKey(key))
        value = map(key);
    else
        value = 0;
    end
end

