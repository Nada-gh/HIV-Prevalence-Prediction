

[id,  resp, pr, rt, vl, cd] = textread('training_data.csv','%u %u %s %s %f %u', 'delimiter',',','headerlines', 1);

positive_vl = [];
negative_vl = [];

positive_cd = [];
negative_cd = [];

pos_idx = 1;
neg_idx = 1;

for i=1:length(rt)
    if (resp(i) == 1) 
        positive_vl(pos_idx) = vl(i);
        positive_cd(pos_idx) = cd(i);
        pos_idx = pos_idx + 1;
    else
        negative_vl(neg_idx) = vl(i);
        negative_cd(neg_idx) = cd(i);
        neg_idx = neg_idx + 1;
    end
end

mean(positive_cd);
mean(negative_cd);

plot(positive_cd, '-g');
hold on;
plot(negative_cd, '-b');
hold off;