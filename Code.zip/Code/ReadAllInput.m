AAPT = readCSVFile('AlignedPT.csv', ',');
AART = readCSVFile('AlignedRT.csv', ',');
temp = csvread('VLCD4.csv');
VL = temp(:,1);
CD4 = temp(:,2);
clear temp
target = csvread('target.csv');
PTfreq = csvread('PTfreqs.csv');
RTfreq = csvread('RTfreqs.csv');

removeAmbiguity;