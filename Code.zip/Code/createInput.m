function output = createInput( PT, RT, VL, CD4 )
%CREATEINPUT Outputs the Input in a matrix. Each row is a different
%patient, and the columns contain the different features.
n = min(size(PT,1), size(RT,1));
numberOfCols = size(PT{1},2) + size(RT{1},2) + 1 + 1;
output = zeros(n, numberOfCols);
for i = 1 : n
    PTvec = aa2int(PT{i})';
    RTvec = aa2int(RT{i})';
    inputVec = [PTvec; RTvec; VL(i); CD4(i)];
    output(i, :) = inputVec';
end

end

