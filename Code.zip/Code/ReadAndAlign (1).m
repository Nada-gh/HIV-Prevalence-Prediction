nnPT = readCSVFile('PT.csv', ',');
nnRT = readCSVFile('RT.csv', ',');

AAPT = nt2aa(nnPT, 'ACGTOnly', false);
AART = nt2aa(nnRT, 'ACGTOnly', false);

[AAPTAligned PTFreq] = Align(AAPT);
[AARTAligned RTFreq] = Align(AART);

writeTocsv('AlignedPT.csv', AAPTAligned);
writeTocsv('AlignedRT.csv', AARTAligned);

csvwrite('PTfreqs.csv', PTFreq);
csvwrite('RTfreqs.csv', RTFreq);