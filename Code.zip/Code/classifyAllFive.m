delete FiveByte.csv
EmailSetup;
lambdas = [8 1 10 3 6]';
HDs = [1500 800 ]';

lambdas = [1]'; %ORTHOGONAL
HDS = [1500]'; % <<<ORTHOGONAL
TrainingPercentages = [0.9]';

emails = { 'aamirtothejawaid@gmail.com' };
currentTime = mat2str(uint16(clock))
attachments = { 'FiveByte.csv' };

ReadAllInput
AART = getSubsetAA(AART, 1, 230);
TotalInput = FiveByteEncoding(AAPT, AART, VL, CD4);
[n inputFeatures] = size(TotalInput);
TotalTarget = target(1:n);

for q = 1 : size(lambdas, 1)
    for p = 1 : size(HDs, 1)
        for r = 1 : size(TrainingPercentages, 1)
            if (lambdas(q) == 1 && TrainingPercentages(r) == 0.8)
               continue; 
            end
            TrainingPercentage = TrainingPercentages(r);
            lambda = lambdas(q);
            hidden_units = HDs(p);
            classifier
            save -ascii FiveByte.csv Results '-append'
            heading = 'threshold lambda hiddenUnits TrainingPercentage TestAccuracy TestAccuracyOnes TrainingAccuracy TrainingAccuracyOnes FalsePositives FalseNegatives TimeSpent cost';
            Q = sprintf('');
            for result = 1 : size(Results, 1)
                Q = sprintf('%s\n%s',Q,mat2str(Results(result,:)));
            end
            S = sprintf('%s\n%s', heading, Q);
            try
                sendmail(emails, 'FiveByte Running...', S);
            catch exception
                % don't do anything..
            end
            clear ~lambdas ~HDs ~TrainingPercentages ~emails ~q ~p ~r ~TotalInput ~n ~inputFeatures ~TotalTarget ~attachments;
        end
    end
end

emails = { 'lordwizards@gmail.com'; 'jeffreyxu951@gmail.com' };

sendmail(emails, 'FiveByte Finished!', 'Attached', attachments);