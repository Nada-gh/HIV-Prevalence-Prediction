function [ TargetIdx, Output, OutputIdx ] = UnderSample( input, target )
%OVERSAMPLE Summary of this function goes here
%   Detailed explanation goes here
[n x] = size(target);
positiveIdx = [1:n]';
positiveIdx = positiveIdx .* target;
positiveIdx(positiveIdx==0) = [];
negativeIdx = [1:n]';
negativeIdx = negativeIdx .* (~target);
negativeIdx(negativeIdx==0) = [];

numberOfPositives = size(positiveIdx,1);
numberOfNegatives = size(negativeIdx,1);

OutputIdx = zeros(min(numberOfPositives, numberOfNegatives) * 2,1);
TargetIdx = zeros(min(numberOfPositives, numberOfNegatives) * 2,1);

% copy the bigger indices directly in first
modded = 0;
times = 0;
higherSetIdx = 0;
posOrneg = -1;
if numberOfPositives < numberOfNegatives
    OutputIdx(1:numberOfPositives) = positiveIdx;
    posOrneg = 0;
    TargetIdx(1:numberOfPositives) = TargetIdx(1:numberOfPositives) + 1;
    lowerSet = negativeIdx;
    higherSetIdx = numberOfPositives;
    modded = mod(numberOfPositives,numberOfNegatives);
else
    OutputIdx(1:numberOfNegatives) = negativeIdx;
    posOrneg = 1;
    lowerSet = positiveIdx;
    higherSetIdx = numberOfNegatives;
    modded = mod(numberOfNegatives,numberOfPositives);
end
lowerSetIdx = size(lowerSet,1);
% replicate 
OutputIdx(higherSetIdx + 1 : end) = lowerSet(1:modded);
TargetIdx(higherSetIdx + 1 : end) = posOrneg;

Output = zeros(size(OutputIdx,1),size(input,2));
for i = 1 : size(Output,1)
    Output(i,:) = input(OutputIdx(i),:);
end
end

