function [J, grad] = costFunction(Theta, input_size, hidden_units, lambda, X, Y)
% Find the cost and gradience for neural networks of 3 layers

% unroll the thetas
Theta1 = reshape(Theta(1:(input_size + 1)*hidden_units), (input_size + 1), hidden_units);
Theta2 = reshape(Theta((1 + input_size)*hidden_units + 1:end),hidden_units + 1,1);

% add a column of ones for each 
[m n] = size(X);
J = 0;
Theta1Grad = zeros(size(Theta1));
Theta2Grad = zeros(size(Theta2));
grad = 0;

% Feedforward
X = [ones(m,1) X];

z2 = X*Theta1;
a2 = sigmoid(z2);
a2 = [ones(m,1) a2];

z3 = a2*Theta2;
h = sigmoid(z3);


J = - 1/m * sum(Y .* log(h) + (1 - Y).*log(1-h));

sigma3 = h - Y;

% X = m * 145
% Theta1 = 145 * 200
% a2 = X*Theta1 = m*200
% Theta2 = 201 * 1

% sigma3 = m*1

%sigma3 * transpose(Theta2) = m * 200
sigma2 = sigma3*transpose(Theta2(2:end,:)) .* (a2(:,2:end) .* (1-a2(:,2:end)));

Theta1Grad = 1/m * transpose(X)*sigma2;	%145*200
Theta2Grad = 1/m * transpose(a2)*sigma3;  %201*1


regularization = lambda / (2*m) * (sum(sum(Theta1(2:end,:).^2)) + sum(sum(Theta2(2:end,:))));

%regularization for grad
regularization_theta1 = lambda / m * Theta1;
regularization_theta2 = lambda / m * Theta2;

%remove the bias from the first column
regularization_theta1(1,:) = zeros(1,size(Theta1,2));
regularization_theta2(1,:) = zeros(1,size(Theta2,2));

Theta1Grad = Theta1Grad + regularization_theta1;
Theta2Grad = Theta2Grad + regularization_theta2;

J = J + regularization;

% Unroll gradients
grad = [Theta1Grad(:) ; Theta2Grad(:)];

end