% Read the entire file
[id,  resp, pr, rt, vl, cd] = textread('training_data.csv','%u %u %s %s %f %u', 'delimiter',',','headerlines', 1);

delete('training_data_in_binary.csv');

fileID = fopen('training_data_in_binary.csv','a');
fprintf(fileID,'PatientID,Resp,PR Seq,RT Seq,VL-t0,CD4-t0\n');

for i=1:length(rt)
    % Convert the Nucleotides to Amino Acids
    pr_amino_acids = nt2aa(pr{i},'ACGTOnly',false);
    
    %
    % TODO : Allighn the Amino Acids and put the result in pr_allighned_amino_acids
    %
    pr_allighned_amino_acids = pr_amino_acids;
    %
    %
    %
    
    % Convert the alighned Amino Acids to integers
    pr_amino_acids_as_int = aa2int(pr_allighned_amino_acids);
    
    % Convert eht integer Amino Acids to 5-Bit binary
    pr_amino_acids_as_binary = dec2bin(pr_amino_acids_as_int,5);
    
    % Initialize the comined Amino Acids Binary to Zero
    pr_amino_acids_combined_binary = '';
    
    % Loop through all the binary and concatinate them into one large
    % binary string
    for j = 1:length(pr_amino_acids_as_binary)
        pr_amino_acids_combined_binary =[pr_amino_acids_combined_binary,pr_amino_acids_as_binary(j,:)];
    end
    
    
    
     % Convert the Nucleotides to Amino Acids
    rt_amino_acids = nt2aa(rt{i},'ACGTOnly',false);
    
    %
    % TODO : Allighn the Amino Acids and put the result in pr_allighned_amino_acids
    %
    rt_allighned_amino_acids = rt_amino_acids;
    %
    %
    %
    
    % Convert the alighned Amino Acids to integers
    rt_amino_acids_as_int = aa2int(rt_allighned_amino_acids);
    
    % Convert eht integer Amino Acids to 5-Bit binary
    rt_amino_acids_as_binary = dec2bin(rt_amino_acids_as_int,5);
    
    % Initialize the comined Amino Acids Binary to Zero
    rt_amino_acids_combined_binary = '';
    
    % Loop through all the binary and concatinate them into one large
    % binary string
    for j = 1:length(rt_amino_acids_as_binary)
        rt_amino_acids_combined_binary =[rt_amino_acids_combined_binary,rt_amino_acids_as_binary(j,:)];
    end
    
    
    fprintf(fileID,'%u,%u,%s,%s,%f,%u\n',id(i), resp(i), pr_amino_acids_combined_binary, rt_amino_acids_combined_binary, vl(i), cd(i));
    
end

fclose(fileID);