delete NoEncoding.csv
EmailSetup;
lambdas = [1 3 6 8 10]';
HDs = [ 331 662 1324 ]';
TrainingPercentages = [0.8 0.85 0.9]';

lambdas = [1 3]';
HDs = [ 331 ]';
TrainingPercentages = [0.90]'

emails = { 'aamirtothejawaid@gmail.com' };
currentTime = mat2str(uint16(clock))
attachments = { 'NoEncoding.csv' };

ReadAllInput
AART = getSubsetAA(AART, 1, 230);
TotalInput = createInput(AAPT, AART, VL, CD4);
[n inputFeatures] = size(TotalInput);
TotalTarget = target(1:n);

for q = 1 : size(lambdas, 1)
    for p = 1 : size(HDs, 1)
        for r = 1 : size(TrainingPercentages, 1)
            TrainingPercentage = TrainingPercentages(r);
            lambda = lambdas(q);
            hidden_units = HDs(p);
            classifier
            save -ascii NoEncoding.csv Results '-append'
            heading = 'threshold lambda hiddenUnits TrainingPercentage TestAccuracy TestAccuracyOnes TrainingAccuracy TrainingAccuracyOnes FalsePositives FalseNegatives TimeSpent cost';
            Q = sprintf('');
            for result = 1 : size(Results, 1)
                Q = sprintf('%s\n%s',Q,mat2str(Results(result,:)));
            end
            S = sprintf('%s\n%s', heading, Q);
            try
                sendmail(emails, 'NoEncoding Running...', S);
            catch exception
            end
            clear ~lambdas ~HDs ~TrainingPercentages ~emails ~q ~p ~r ~TotalInput ~n ~inputFeatures ~TotalTarget ~attachments;
        end
    end
end

% append the best training results
[MaxTrainingAccValue MaxTrainingAccIdx] = max(Results(:, 5));
[MaxTrainingOneAccValue MaxTrainingOneAccIdx] = max(Results(:, 6));

str1 = Results(MaxTrainingAccIdx, :);
str2 = Results(MaxTrainingOneAccIdx, :);

save -ascii NoEncoding.csv str1 '-append';
save -ascii NoEncoding.csv str2 '-append';

emails = { 'lordwizards@gmail.com'; 'jeffreyxu951@gmail.com' };
sendmail(emails, 'NoEncoding Final Results!', 'Attached', attachments);